package com.grupo56.proyectoIngeBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoIngeBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
